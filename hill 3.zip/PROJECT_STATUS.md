# PROJECT_STATUS - Hill Climb Adventure

## Project
- Name: Hill Climb Adventure
- Description: 2D side-scrolling physics racing game inspired by Hill Climb Racing (landscape; Android, tablet, desktop; no backend)
- Technologies: HTML5 Canvas, CSS, JavaScript, Matter.js (user supplies libs/matter.min.js; offline)

## Folder structure
- index.html: canvas, HUD, menu/pause/game-over overlays
- css/style.css: flat/minimal desert UI (system sans-serif)
- js/audio.js: synthesized sounds + music
- js/vehicles.js: vehicle stats/physics data
- js/game.js: config, save, terrain, Matter world + truck, step loop, rendering, input
- libs/: put matter.min.js here (NOT included)

## Current stage
Stage 1 play-tested once by user (fixes in v2); Stage 2 sound/effects added.

## Completed features (Stage 1)
- Monster Truck (Matter.js chassis, 2 wheels, spring suspension), flat desert terrain that gets steeper with distance
- Gas / brake-reverse; air balance (gas = nose up, brake = nose down, A/D keys); wheel rotation
- Coins, fuel cans, fuel bar, distance, speed, pause; game over (crash / out of fuel); Retry / Main menu
- Dust particles, button-press animation, parallax dunes, smooth camera
- LocalStorage: total coins and best distance
- Controls: touch buttons (brake left-bottom, gas right-bottom), keyboard Right/Left arrows, A/D

## Stage 2 (in progress): sound + effects
- Done: js/audio.js (Web Audio synth, no files): engine + tire sound, coin, fuel, jump, landing, crash, game-over, chiptune music; pause-menu Sound/Music switches (saved); landing dust burst + camera shake
- Untested in a real browser (written without running audio)

## Stage 3 (in progress): garage + vehicles
- Done: js/vehicles.js (Monster Truck, Jeep, Motocross Bike, Sports Car with own physics values), slider garage (big preview, arrows, stats bars), unlock with coins (Jeep 200, Bike 350, Sports Car 500), selected vehicle saved; Garage buttons on menu and game over
- Not tested in a browser; new vehicles' physics need tuning

## Pending features
- Stage 4+: remaining 8 vehicles, 11 vehicles, 9 maps, garage, maps screen, upgrades, settings, unlock system, full save, device-tilt control, per-vehicle/map physics

## Important design decisions (approved by user)
- Start with Monster Truck + Desert; flat/minimal graphics; Matter.js; user downloads matter.min.js into libs/
- Layout: brake bottom-left, gas bottom-right, fuel/coins/distance at top; warm sand/orange palette, light yellow sky; dust particles + button animation

## Known bugs / risks
- Play test 2: gas did nothing (v2 bug: ground flags were cleared before the drive code read them) -> fixed in v3; top speed raised so the truck can launch off hills. Needs re-test.
- Play test 1: front wheel lifted too high (wheelie) and steep hills not climbable -> v2 lowers acceleration, raises grip, adds anti-wheelie damping (needs re-test). Sky/ground colors were too similar -> ground is now dark brown.
- Physics could not be run in the build sandbox (no Matter.js there): suspension, drive and flip values in TRUCK (js/game.js) probably need tuning after the first play test.
- Device-tilt sensor not implemented yet; air balance uses buttons/keys.

## Next steps
1. User plays Stage 1 and reports feel (suspension, speed, difficulty, bugs)
2. Tune physics, then Stage 2

## Last working point
Stage 2 sound/effects added; awaiting user play test (physics v2 + audio).

## Run
Put matter.min.js in libs/, then open index.html (or serve with: python3 -m http.server) and open in browser; Android: host it or open from a local server.
